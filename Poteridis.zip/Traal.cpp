//
//  Traal.cpp
//  Poteridis
//
//  Created on 29/5/21.
//

#include <stdlib.h>
#include "Traal.hpp"

Traal::Traal(int row, int col, WINDOW *win): Moving(row, col, 'T', win, 'P'){
    direction = 1;
    rounds = 0;
}

int Traal::move(){
    bool has_eaten_potter = false;
    int result = -1;
    int can_move_result = 0;
    
    rounds++;
    
    // mia sto toso allakse katefthinsi tixaia
    if (rounds > 10 && rand() % 10 > 5){
        direction = rand() % 4 + 1;
    }
    
    // arxise tin metrisi apo tin arxi kai
    // allakse kai katefthinsi
    if (rounds > 21) {
        direction = rand() % 4 + 1;
        rounds = 0;
    }
    
    do{
        switch (direction){
            case 1:
                if ((can_move_result = isValidMove(row + 1, col)) > -1){
                    result = moveDown();
                }
                break;
            case 2:
                if ((can_move_result = isValidMove(row - 1, col)) > -1){
                    result = moveUp();
                }
                break;
            case 3:
                if ((can_move_result = isValidMove(row, col + 1)) > -1){
                    result = moveRight();
                }
                break;
            default:
                if ((can_move_result = isValidMove(row, col - 1)) > -1){
                    result = moveLeft();
                }
        }
        
        // an den boro na kano kinisi pros tin katefthinsi pou thelo
        // allazo katefthinsi
        if (can_move_result == -1){
            direction = rand() % 4 + 1;
        }
    }while (can_move_result == -1);
    
    
    if (result == 1) has_eaten_potter = true;
    
    return has_eaten_potter;
}
