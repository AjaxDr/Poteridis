//
//  Score.cpp
//  Poteridis
//
//  Created on 29/5/21.
//

#include "Score.hpp"


Score::Score(string name, int points): points(points){
    if (name.length() > MAX_NAME_LENGTH)        
        this->name = name.erase(MAX_NAME_LENGTH);
    else
        this->name = name;
}
int Score::getPoints(){ return points; }
string Score::getName(){ return name; }
bool operator<(const Score& l, const Score& r){ return l.points < r.points; }
bool operator>(const Score& l, const Score& r){ return l.points > r.points; }
bool operator<=(const Score& l, const Score& r){ return l.points <= r.points; }
bool operator>=(const Score& l, const Score& r){ return l.points >= r.points; }
bool operator==(const Score& l, const Score& r){ return l.points == r.points; }
bool operator!=(const Score& l, const Score& r){ return l.points != r.points; }

ostream& operator<<(ostream& os, const Score& score){
    os << score.name << ": " << score.points;
    
    return os;
}
