//
//  Moving.cpp
//  Poteridis
//
//  Created on 29/5/21.
//

#include <math.h>
#include "Moving.hpp"

int Moving::moveUp(){
    int result;
    if ((result = isValidMove(row - 1, col)) > -1){
        mvwaddch(win, row, col, ' ');
        row--;
        mvwaddch(win, row, col, character);
    }
    return result;
}
int Moving::moveDown(){
    int result;
    if ((result = isValidMove(row + 1, col)) > -1){
        mvwaddch(win, row, col, ' ');
        row++;
        mvwaddch(win, row, col, character);
    }
    return result;
}
int Moving::moveLeft(){
    int result;
    if ((result = isValidMove(row, col-1)) > -1){
        mvwaddch(win, row, col, ' ');
        col--;
        mvwaddch(win, row, col, character);
    }
    return result;
}
int Moving::moveRight(){
    int result;
    if ((result = isValidMove(row, col+1)) > -1){
        mvwaddch(win, row, col, ' ');
        col++;
        mvwaddch(win, row, col, character);
    }
    return result;
}

Moving::Moving(int row, int col, char character, WINDOW* win, char can_eat_character_1):
    row(row), col(col), character(character), win(win), can_eat_character_1(can_eat_character_1)
{
    mvwaddch(win, row, col, character);
}

Moving::Moving(int row, int col, char character, WINDOW* win, char can_eat_character_1, char can_eat_character_2):
    row(row), col(col), character(character), win(win), can_eat_character_1(can_eat_character_1), can_eat_character_2(can_eat_character_2)
{
    mvwaddch(win, row, col, character);
}

int Moving::isValidMove(int new_row, int new_col){
    chtype new_position = mvwinch(win, new_row, new_col);
    
    if (new_position == ' ') return 0;  // otan epistrefoume 0, den trome tipota
    else if (new_position == can_eat_character_1 || new_position == can_eat_character_2) return 1; // kati fagame
    return -1; // i kinisi den einai sosti
}

char Moving::get_character(){
    return character;
}

double Moving::get_distance(const Moving& player, int row, int col){
    double distance;
    
    distance = sqrt(pow((double)player.row - (double)row, 2.0) + pow((double)player.col - (double)col, 2.0));
    
    return distance;
}
