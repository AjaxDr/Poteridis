//
//  HiScore.cpp
//  Poteridis
//
//  Created on 29/5/21.
//

#include <fstream>

#include "HiScore.hpp"
#include "Score.hpp"



HiScore::HiScore(string filename): filename(filename){
    ifstream infile(filename, ios::in | ios::binary);
    int numScores, name_length, points;
    char name[MAX_NAME_LENGTH + 1];
    
    temp_score = -1;
    temp_name = "";
    
    if (!infile.bad()) {
        
    
        infile.read((char*)&numScores, sizeof(int));
        
        for (int i = 0 ; i < numScores ; i++){
            infile.read((char*)&name_length, sizeof(int));
            infile.read(name, name_length);
            infile.read((char*)&points, sizeof(int));
            
            name[name_length] = '\0';
            
            *this << name << points;
        }
    
        infile.close();
    }
    else throw "Cannot open file of scores";
    
}

HiScore::~HiScore() {
    ofstream outfile;
    int len, points;
    char *name = NULL;
    
    
    outfile.open(filename, ios::out | ios::binary);
    
    if (outfile.bad() || !outfile) {
        throw "Cannot save to file of scores";
    }
    
    len = (int)scores.size();
    outfile.write((char*)&len, sizeof(int));
    
    for (int i = 0 ; i < scores.size() ; i++){
        points = scores[i].getPoints();
        name = strdup(scores[i].getName().c_str());
        len = (int)strlen(name);
        
        outfile.write((char*)&len, sizeof(int));
        outfile.write(name, len);
        outfile.write((char*)&points, sizeof(int));
        
        free(name);
    }
    
    outfile.close();
}

void HiScore::check_new_score(const Score& newScore){
    scores.push_back(newScore);
    
    sort(scores.begin(), scores.end());
    reverse(scores.begin(), scores.end());
    
    if (scores.size() > SIZE){
        scores.pop_back();
    }
}


HiScore& HiScore::operator<<(int points){
    temp_score = points;

    
    if ( !temp_name.empty() ){
        Score newScore(temp_name, temp_score);
        check_new_score(newScore);
        
        temp_name.clear();
        temp_score = -1;
    }
    
    return *this;
}
HiScore& HiScore::operator<<(string name){
    temp_name = name;
    
    //cout << "got new name: " << name << " score is: " << temp_score << endl;
    
    if ( temp_score > -1 ){
        Score newScore(temp_name, temp_score);
        check_new_score(newScore);
        
        temp_name.clear();
        temp_score = -1;
    }
    
    return *this;
}
void HiScore::print(){
    cout << "The score is:" << endl;
    
    for (int i = 0 ; i < scores.size() ; i++){
        cout << " > " << scores[i] << endl;
    }
}
