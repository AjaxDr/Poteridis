//
//  Score.hpp
//  Poteridis
//
//  Created on 29/5/21.
//

#ifndef Score_hpp
#define Score_hpp

#include <stdio.h>
#include <iostream>

#define MAX_NAME_LENGTH 10
#define STONE_POINTS    10
#define PAPER_POINTS    100

using namespace std;



class Score{
private:
    string name;
    int points;
    
public:
    Score(string name, int points);
    int getPoints();
    string getName();
    
    friend bool operator<(const Score& l, const Score& r);
    friend bool operator>(const Score& l, const Score& r);
    friend bool operator<=(const Score& l, const Score& r);
    friend bool operator>=(const Score& l, const Score& r);
    friend bool operator==(const Score& l, const Score& r);
    friend bool operator!=(const Score& l, const Score& r);
    
    friend ostream& operator<<(ostream&, const Score&);
};

#endif /* Score_hpp */
