//
//  Engine.cpp
//  Poteridis
//
//  Created on 29/5/21.
//


#include <fstream>
#include <iostream>
#include <ncurses.h>

#include "Engine.hpp"


#define TICKRATE 200

using namespace std;


enum direction { UP, DOWN, RIGHT, LEFT };
 


#define WORLD_WIDTH 50
#define WORLD_HEIGHT 20

Engine::Engine(const char* map_filename, const char* scores_filename){
    
    ifstream infile;
    
    // arxika des an boreis na diavaseis ton xarti
    infile.open(map_filename, ios::in);
    string line, cont;
    
    if (infile.ios_base::bad()){
        cout << "no file for map is loaded!" << endl;
        return;
    }
    
    while (!infile.ios_base::fail() && !infile.ios_base::eof() && getline(infile, line)){
        game_map.push_back(line);
    }
    
    infile.close();
    
    labyrinth_rows = (int)game_map.size();
    labyrinth_cols = (int)game_map[0].length();
    
    
    try{
        hiScore = new HiScore(scores_filename);
    }
    catch (char* msg){
        cout << msg << endl;
    }
}

void Engine::start(){
    string name;
    
    cout << "Enter your name: " ;
    cin >> name;
    
    draw_labyrinth();
    
    int score = play_game();
    
    *hiScore << name << score;
    
    hiScore->print();
}

int Engine::play_game(){
    chtype ch;
    int result, pieces_left = NUMBER_OF_STONES + 1, ptuxio = 0;
    
    mvprintw(labyrinth_rows + 3, 1, "Press S to start!");
    while ( ( ch = getch() ) != 'S' && ( ch = getch() ) != 's');
    
    while (pieces_left > 0 ) {
        ch = getch();
        
        if (ch == 27) break;
        
        result = potter->move(ch);
        if (result == 1) pieces_left--;
        if (pieces_left == 1 && ptuxio == 0) {
            show_ptuxio();
            ptuxio++;
        }
        
        result = gnome->move(*potter);
        if (result == 1) {
            mvprintw(labyrinth_rows + 4, 1, "Eaten by gnome!");
            break;
        }
        
        result = traal->move();
        if (result == 1) {
            mvprintw(labyrinth_rows + 4, 1, "Eaten by traal!");
            break;
        }
        
        mvprintw(labyrinth_rows + 3, 1, "Stones left: %2d, Score: %2d", pieces_left - 1, NUMBER_OF_STONES - pieces_left - 1);
        wrefresh(win);
    }
    
    while ( ( ch = getch() ) != 27);
    
    delwin(win);
     
    endwin();
    
    return NUMBER_OF_STONES - pieces_left - 1;
}

void Engine::show_ptuxio(){
    int random_row, random_col;
    chtype ch;
    
    
    while (1){
        random_row = rand() % (labyrinth_rows - 2) + 1;
        random_col = rand() % (labyrinth_cols - 2) + 1;
        
        ch = mvwinch(win, random_row, random_col);
        
        if (ch == ' '){
            mvwaddch(win, random_row, random_col, 'V');
            break;
        }
    }
    
}

void Engine::add_players(){
    int i, random_row, random_col;
    chtype ch;
    
    
    i = 0;
    
    while (i < 3){
        random_row = rand() % (labyrinth_rows - 2) + 1;
        random_col = rand() % (labyrinth_cols - 2) + 1;
        
        ch = mvwinch(win, random_row, random_col);
        
        if (i == 0 && ch == ' '){
            potter = new Potter(random_row, random_col, win);
            i++;
        }
        else if (i == 1 && ch == ' '){
            gnome = new Gnome(random_row, random_col, win);
            i++;
        }
        else if (i == 2 && ch == ' '){
            traal = new Traal(random_row, random_col, win);
            i++;
        }
    }
}

void Engine::add_stones(){
    int i, random_row, random_col;
    chtype ch;
    
    
    i = 0;
    
    while (i < NUMBER_OF_STONES){
        random_row = rand() % (labyrinth_rows - 2) + 1;
        random_col = rand() % (labyrinth_cols - 2) + 1;
        
        ch = mvwinch(win, random_row, random_col);
        
        if (ch == ' '){
            mvwaddch(win, random_row, random_col, 'S');
            i++;
        }
    }
}



int Engine::draw_labyrinth(){
    int rows = (int)game_map.size() + 2;
    int cols = (int)game_map[0].length() + 2;
    WINDOW* snakeys_world;
    
    int offsetx, offsety, i;
     
    initscr();
    printw("Poteridis v. 1.0  -  Press [ESC] to quit...");
    noecho();
    curs_set(0);

    cbreak();
    timeout(TICKRATE);
    keypad(stdscr, TRUE);
     
     
    refresh();
     
    offsetx = 1;
    offsety = 1;
     
    win = snakeys_world = newwin(rows, cols, offsety, offsetx);

    char *l;
    for (i = 0 ; i < game_map.size() ; i++){
        l = strdup(game_map[i].c_str());
        mvwprintw(win, i+1, 1, l);
    }
    
    add_stones();
    add_players();
    
    box(win, 0 , 0);

    wrefresh(win);
    
    

    
    return 0;
}

