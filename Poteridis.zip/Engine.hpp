//
//  Engine.hpp
//  Poteridis
//
//  Created on 29/5/21.
//

#ifndef Engine_hpp
#define Engine_hpp

#include <stdio.h>
#include <ncurses.h>
#include <vector>

#include "HiScore.hpp"
#include "Potter.hpp"
#include "Gnome.hpp"
#include "Traal.hpp"

using namespace std;



class Engine {
private:
    static const int NUMBER_OF_STONES = 10;
    vector<string> game_map;
    HiScore* hiScore;
    WINDOW *win;
    int labyrinth_rows;
    int labyrinth_cols;
    
    Potter* potter;
    Gnome* gnome;
    Traal* traal;
    
    typedef struct spart {
        int x;
        int y;
    } snakeypart;
    
    int draw_labyrinth();
    int move_snakey(WINDOW *win, int direction, snakeypart snakey[]);
    void add_stones();
    void add_players();
    int play_game();
    void show_ptuxio();
public:
    Engine(const char*, const char*);
    void start();
};

#endif /* Engine_hpp */
