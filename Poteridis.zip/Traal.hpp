//
//  Traal.hpp
//  Poteridis
//
//  Created on 29/5/21.
//

#ifndef Traal_hpp
#define Traal_hpp

#include <stdio.h>

#include "Moving.hpp"

class Traal: public Moving{
private:
    int direction, rounds;
public:
    Traal(int row, int col, WINDOW *win);
    int move();
};

#endif /* Traal_hpp */
