//
//  Gnome.cpp
//  Poteridis
//
//  Created on 29/5/21.
//
#include <math.h>
#include "Gnome.hpp"


Gnome::Gnome(int row, int col, WINDOW *win): Moving(row, col, 'G', win, 'P'){
    
}

bool Gnome::move(const Moving& potter){
    bool has_eaten_potter = false;
    //int distance;
    int result = -1;
    int can_move_result = 0;
    double min_distance;
    int direction = 0;
    
    min_distance = get_distance(potter, row, col) + 10;
    
    if ((can_move_result = isValidMove(row + 1, col)) > -1){
        if (can_move_result == 1){
            result = moveDown();
        }
        else if (get_distance(potter, row + 1, col) < min_distance){
            direction = 1;
            min_distance = get_distance(potter, row + 1, col);
        }
    }
    if ((can_move_result = isValidMove(row - 1, col)) > -1){
        if (can_move_result == 1){
            result = moveUp();
        }
        else if (get_distance(potter, row - 1, col) < min_distance){
            direction = 2;
            min_distance = get_distance(potter, row - 1, col);
        }
    }
    if ((can_move_result = isValidMove(row, col + 1)) > -1){
        if (can_move_result == 1){
            result = moveRight();
        }
        else if (get_distance(potter, row, col + 1) < min_distance){
            direction = 3;
            min_distance = get_distance(potter, row, col + 1);
        }
    }
    if ((can_move_result = isValidMove(row, col - 1)) > -1){
        if (can_move_result == 1){
            result = moveLeft();
        }
        else if (get_distance(potter, row, col - 1) < min_distance){
            direction = 4;
            min_distance = get_distance(potter, row, col - 1);
        }
    }
    
    if (result == -1){
        switch (direction){
            case 1: result = moveDown(); break;
            case 2: result = moveUp(); break;
            case 3: result = moveRight(); break;
            case 4: result = moveLeft(); break;
        }
    }
    
    if (result == 1) has_eaten_potter = true;
    
    return has_eaten_potter;
}
