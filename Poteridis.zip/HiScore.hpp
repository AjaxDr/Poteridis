//
//  HiScore.hpp
//  Poteridis
//
//  Created on 29/5/21.
//

#ifndef HiScore_hpp
#define HiScore_hpp

#include <stdio.h>
#include <vector>


#include "Score.hpp"

#define SIZE 5

class HiScore{
private:
    vector<Score> scores;
    int temp_score;
    string temp_name;
    string filename;
    
    
    void check_new_score(const Score& newScore);
public:
    HiScore(string filename);
    ~HiScore() ;
    HiScore& operator<<(int);
    HiScore& operator<<(string);
    void print();
};

#endif /* HiScore_hpp */
