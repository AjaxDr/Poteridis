//
//  main.cpp
//  Poteridis
//
//  Created on 29/5/21.
//

/*
g++ *.cpp -lncurses
./a.out data.txt HiScores.dat
*/

#include <iostream>
#include <time.h>

#include "Engine.hpp"
#include "HiScore.hpp"

using namespace std;

int main(int argc, const char * argv[]) {
    
    
    srand((unsigned int)time(NULL));
    
    if (argc != 3){
        cout << "Must provide map filename and high-score filename!" << endl;
        return 1;
    }
    
    Engine e(argv[1], argv[2]);
    e.start();
    
    //HiScore h(argv[2]);
    //h.print();
    
    
    return 0;
}

