//
//  Gnome.hpp
//  Poteridis
//
//  Created on 29/5/21.
//

#ifndef Gnome_hpp
#define Gnome_hpp

#include <stdio.h>

#include "Moving.hpp"

class Gnome: public Moving{
public:
    Gnome(int row, int col, WINDOW *win);
    bool move(const Moving& potter);
};

#endif /* Gnome_hpp */
