//
//  Moving.hpp
//  Poteridis
//
//  Created on 29/5/21.
//

#ifndef Moving_hpp
#define Moving_hpp

#include <stdio.h>
#include <ncurses.h>

class Moving{
private:
    char character;
    char can_eat_character_1;
    char can_eat_character_2;
    WINDOW* win;
    
protected:
    int row, col;
    int moveUp();
    int moveDown();
    int moveLeft();
    int moveRight();
    double get_distance(const Moving&, int, int);
    
public:
    Moving(int row, int col, char character, WINDOW* win, char can_eat_character_1);
    Moving(int row, int col, char character, WINDOW* win, char can_eat_character_1, char can_eat_character_2);
    char get_character();
    int isValidMove(int new_row, int new_col);
};

#endif /* Moving_hpp */
