//
//  Potter.cpp
//  Poteridis
//
//  Created on 29/5/21.
//

#include "Potter.hpp"


Potter::Potter(int row, int col, WINDOW *win): Moving(row, col, 'P', win, 'S', 'V'){
    
}

int Potter::move(chtype ch){
    //bool success = true;
    
    if(ch != ERR && ch != 27) {
        switch(ch) {
            case KEY_UP:
                return moveUp();
                break;
            case KEY_DOWN:
                return moveDown();
                break;
            case KEY_RIGHT:
                return moveRight();
                break;
            case KEY_LEFT:
                return moveLeft();
                break;
        }
    }
    
    return 0;
    //return success;
}
