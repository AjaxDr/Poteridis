//
//  Potter.hpp
//  Poteridis
//
//  Created on 29/5/21.
//

#ifndef Potter_hpp
#define Potter_hpp

#include <stdio.h>

#include "Moving.hpp"

class Potter: public Moving{
public:
    Potter(int row, int col, WINDOW *win);
    int move(chtype key);
};

#endif /* Potter_hpp */
